package javafiles.interfaces;

import javafx.stage.Stage;

public interface InitStage {


     void setStage(Stage stage);

}
